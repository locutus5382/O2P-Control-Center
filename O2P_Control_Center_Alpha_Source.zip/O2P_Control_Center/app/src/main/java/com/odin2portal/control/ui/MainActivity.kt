package com.odin2portal.control.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.odin2portal.control.domain.CpuPolicy
import com.odin2portal.control.domain.DeviceSnapshot
import com.odin2portal.control.domain.Parsing
import com.odin2portal.control.hardware.AccessMode
import com.odin2portal.control.hardware.HardwareRead
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val colors = darkColorScheme(
                primary = Color(0xFF72CBB1),
                secondary = Color(0xFFA3B5CC),
                surface = Color(0xFF152238),
                background = Color(0xFF091322)
            )
            MaterialTheme(colorScheme = colors) {
                val model: DashboardViewModel = viewModel()
                val state by model.state.collectAsState()
                Surface(modifier = Modifier.fillMaxSize()) {
                    Dashboard(
                        state = state,
                        refresh = model::refresh,
                        export = { snapshot ->
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "O2P hardware diagnostic")
                                putExtra(Intent.EXTRA_TEXT, snapshot.diagnosticText())
                            }
                            startActivity(Intent.createChooser(intent, "Share diagnostic"))
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun Dashboard(
    state: DashboardState,
    refresh: (AccessMode) -> Unit,
    export: (DeviceSnapshot) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("O2P Control Center", style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold)
        Text("Hardware Explorer · Alpha 0.1", color = MaterialTheme.colorScheme.secondary)
        Surface(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.13f),
            shape = MaterialTheme.shapes.medium) {
            Text("SAFE READ-ONLY MODE  ·  No CPU, GPU, memory, fan or boot settings are changed.",
                modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
        }
        Text("Access method", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !state.busy, onClick = { refresh(AccessMode.DIRECT_ONLY) }) {
                Text("Direct")
            }
            OutlinedButton(enabled = !state.busy, onClick = { refresh(AccessMode.PSERVER) }) {
                Text("PServer")
            }
            OutlinedButton(enabled = !state.busy, onClick = { refresh(AccessMode.ROOT) }) {
                Text("Root (su)")
            }
        }
        Text("PServer and Root are attempted only when selected. Root may prompt for permission.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        if (state.busy) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text("Reading actual device capabilities…")
        }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        state.result?.let { snapshot ->
            DeviceSummary(snapshot)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = !state.busy, onClick = { refresh(state.mode) }) {
                    Text("Refresh")
                }
                Button(onClick = { export(snapshot) }) { Text("Share report") }
            }
            Section("CPU policies (${snapshot.cpus.size})") {
                if (snapshot.cpus.isEmpty()) Text("No policies could be verified")
                snapshot.cpus.forEach { CpuCard(it) }
            }
            Section("Adreno / GPU") {
                snapshot.gpuNodes.forEach { read ->
                    ReadingRow(read.path.substringAfterLast('/'), read)
                }
            }
            Section("Thermal sensors (${snapshot.thermals.size})") {
                if (snapshot.thermals.isEmpty()) Text("No sensor readings available")
                snapshot.thermals.forEach { zone ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${zone.type.value ?: "zone${zone.index}"}  [${zone.index}]",
                            modifier = Modifier.weight(1f), maxLines = 1,
                            overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.width(10.dp))
                        Text(zone.readableTemperature(), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Section("Memory and pressure") {
                val mem = snapshot.memory.value
                ReadingRowText("Total RAM", prettyMemory(Parsing.memoryKb(mem, "MemTotal")))
                ReadingRowText("Available RAM", prettyMemory(Parsing.memoryKb(mem, "MemAvailable")))
                ReadingRowText("Swap total", prettyMemory(Parsing.memoryKb(mem, "SwapTotal")))
                ReadingRowText("Swap free", prettyMemory(Parsing.memoryKb(mem, "SwapFree")))
                ReadingRowText("Memory PSI", snapshot.pressure.value
                    ?.lineSequence()?.firstOrNull() ?: snapshot.pressure.error ?: "Unavailable")
            }
            Section("Validation notes") {
                snapshot.diagnostics.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            }
        }
        Text("O2PKernelTurb remains separate and unchanged. No AutoPilot tuning is enabled in this alpha.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary)
        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun DeviceSummary(s: DeviceSnapshot) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(s.model, style = MaterialTheme.typography.titleLarge)
            Text("Android ${s.androidVersion}", color = MaterialTheme.colorScheme.secondary)
            ReadingRowText("Requested access", s.accessMode.name)
            ReadingRowText("Transport check", if (s.privilege.available) "Verified" else "Unavailable")
            ReadingRowText("Reported UID", s.privilege.reportedUid?.toString() ?: "Unverified")
            Text(s.privilege.reason, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun CpuCard(cpu: CpuPolicy) {
    HorizontalDivider()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(cpu.name, fontWeight = FontWeight.Bold)
        ReadingRowText("CPUs", cpu.relatedCpus.value ?: "Unavailable")
        ReadingRowText("Current", prettyKHz(cpu.currentKHz.value))
        ReadingRowText("Minimum ceiling", prettyKHz(cpu.minKHz.value))
        ReadingRowText("Current maximum", prettyKHz(cpu.maxKHz.value))
        ReadingRowText("Hardware maximum", prettyKHz(cpu.hardwareMaxKHz.value))
        val levels = Parsing.frequencyList(cpu.availableKHz.value)
        ReadingRowText("Frequency levels", if (levels.isEmpty()) "Unavailable" else "${levels.size} discovered")
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun ReadingRow(label: String, reading: HardwareRead) {
    ReadingRowText(label, reading.value?.take(100) ?: reading.error ?: "Unavailable")
}

@Composable
private fun ReadingRowText(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top) {
        Text(label, modifier = Modifier.weight(0.45f),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        Text(value, modifier = Modifier.weight(0.55f),
            style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}

private fun prettyKHz(raw: String?): String = raw?.toDoubleOrNull()?.let {
    String.format(Locale.US, "%.2f GHz (%s kHz)", it / 1_000_000.0, raw)
} ?: "Unavailable"

private fun prettyMemory(valueKb: Long?): String = valueKb?.let {
    String.format(Locale.US, "%.2f GiB", it / (1024.0 * 1024.0))
} ?: "Unavailable"
